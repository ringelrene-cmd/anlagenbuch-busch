@echo off
setlocal
set "DEST=%LOCALAPPDATA%\Busch Group\Anlagenbuch-Begleiter"
if not exist "%DEST%\Anlagenbuch.ico" (
  echo Bitte zuerst Installieren.cmd ausfuehren.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$desktop=[Environment]::GetFolderPath('Desktop');$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut((Join-Path $desktop 'Anlagenbuch Web - Busch Group.lnk'));$s.TargetPath=(Join-Path $env:WINDIR 'explorer.exe');$s.Arguments='https://anlagenbuch-busch.pages.dev';$s.WorkingDirectory='%DEST%';$s.IconLocation='%DEST%\Anlagenbuch.ico,0';$s.Description='Anlagenbuch Web - Busch Group';$s.Save()"
echo Desktop-Verknuepfung wurde erstellt.
pause
