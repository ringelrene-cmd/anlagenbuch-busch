@echo off
setlocal
set "DEST=%LOCALAPPDATA%\Busch Group\Anlagenbuch-Begleiter"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0Anlagenbuch-Begleiter.ps1" "%DEST%\" >nul
copy /Y "%~dp0Start-Begleiter.vbs" "%DEST%\" >nul
copy /Y "%~dp0siren.wav" "%DEST%\" >nul
copy /Y "%~dp0Anlagenbuch.ico" "%DEST%\" >nul
copy /Y "%~dp0WEB-ANLAGENBUCH.url" "%DEST%\" >nul
powershell.exe -NoProfile -Command "$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut([Environment]::GetFolderPath('Startup')+'\Anlagenbuch Begleiter.lnk');$s.TargetPath='wscript.exe';$s.Arguments='\"%DEST%\Start-Begleiter.vbs\"';$s.WorkingDirectory='%DEST%';$s.IconLocation='%DEST%\Anlagenbuch.ico';$s.Save();$d=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Anlagenbuch Web - Busch Group.lnk');$d.TargetPath=(Join-Path $env:WINDIR 'explorer.exe');$d.Arguments='https://anlagenbuch-busch.pages.dev';$d.WorkingDirectory='%DEST%';$d.IconLocation='%DEST%\Anlagenbuch.ico,0';$d.Description='Anlagenbuch Web - Busch Group';$d.Save()"
start "" wscript.exe "%DEST%\Start-Begleiter.vbs"
echo Anlagenbuch Begleiter wurde installiert.
echo Die Desktop-Verknuepfung mit dem neuen BUSCH-Logo wurde ebenfalls erstellt.
pause
