$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$BaseUrl='https://anlagenbuch-busch.pages.dev'
$Dir=Split-Path -Parent $MyInvocation.MyCommand.Path
$Cfg=Join-Path $env:LOCALAPPDATA 'Busch Group\Anlagenbuch-Begleiter'
New-Item -ItemType Directory -Force -Path $Cfg | Out-Null
$PwFile=Join-Path $Cfg 'web-password.txt'; $SeenFile=Join-Path $Cfg 'seen-faults.json'
function Get-Plain([Security.SecureString]$s){$b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s);try{[Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b)}}
function Load-Password(){try{$raw=Get-Content $PwFile -Raw;$sec=ConvertTo-SecureString $raw;return Get-Plain $sec}catch{return ''}}
function Save-Password([string]$p){$sec=ConvertTo-SecureString $p -AsPlainText -Force;ConvertFrom-SecureString $sec | Set-Content -Encoding ascii $PwFile}
function Ask-Password(){
 $f=New-Object Windows.Forms.Form;$f.Text='Anlagenbuch Begleiter';$f.Width=430;$f.Height=190;$f.StartPosition='CenterScreen';$f.TopMost=$true
 $l=New-Object Windows.Forms.Label;$l.Text='Passwort der Anlagenbuch-Web-Version:';$l.AutoSize=$true;$l.Left=18;$l.Top=18;$f.Controls.Add($l)
 $t=New-Object Windows.Forms.TextBox;$t.Left=18;$t.Top=47;$t.Width=375;$t.UseSystemPasswordChar=$true;$f.Controls.Add($t)
 $b=New-Object Windows.Forms.Button;$b.Text='Speichern';$b.Left=290;$b.Top=87;$b.Width=103;$b.DialogResult='OK';$f.AcceptButton=$b;$f.Controls.Add($b)
 if($f.ShowDialog() -eq 'OK' -and $t.Text){Save-Password $t.Text;return $t.Text};return ''
}
function New-AnlagenbuchDesktopShortcut([bool]$showMessage=$true){
 try{
  $desktop=[Environment]::GetFolderPath('Desktop')
  $shortcutPath=Join-Path $desktop 'Anlagenbuch Web - Busch Group.lnk'
  $shell=New-Object -ComObject WScript.Shell
  $shortcut=$shell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath=Join-Path $env:WINDIR 'explorer.exe'
  $shortcut.Arguments=$BaseUrl
  $shortcut.WorkingDirectory=$Dir
  $shortcut.IconLocation=(Join-Path $Dir 'Anlagenbuch.ico')+',0'
  $shortcut.Description='Anlagenbuch Web - Busch Group'
  $shortcut.Save()
  if($showMessage){[Windows.Forms.MessageBox]::Show("Desktop-Verknüpfung wurde erstellt.`r`n`r`n$shortcutPath",'Anlagenbuch Begleiter') | Out-Null}
  return $true
 }catch{
  if($showMessage){[Windows.Forms.MessageBox]::Show("Desktop-Verknüpfung konnte nicht erstellt werden.`r`n`r`n$($_.Exception.Message)",'Anlagenbuch Begleiter') | Out-Null}
  return $false
 }
}
$Password=Load-Password;if(-not $Password){$Password=Ask-Password};if(-not $Password){exit}
$notify=New-Object Windows.Forms.NotifyIcon;$notify.Icon=New-Object Drawing.Icon (Join-Path $Dir 'Anlagenbuch.ico');$notify.Text='Anlagenbuch Begleiter';$notify.Visible=$true
$menu=New-Object Windows.Forms.ContextMenuStrip
$open=$menu.Items.Add('Web-Anlagenbuch öffnen')
$desktopLink=$menu.Items.Add('Desktop-Verknüpfung erstellen')
$refresh=$menu.Items.Add('Jetzt aktualisieren')
$overview=$menu.Items.Add('Kleine Übersicht')
$change=$menu.Items.Add('Passwort ändern')
$quit=$menu.Items.Add('Beenden')
$notify.ContextMenuStrip=$menu
$script:running=$true;$script:force=$true;$script:last=$null
$open.add_Click({Start-Process $BaseUrl})
$desktopLink.add_Click({New-AnlagenbuchDesktopShortcut $true | Out-Null})
$notify.add_DoubleClick({Start-Process $BaseUrl})
$refresh.add_Click({$script:force=$true})
$change.add_Click({$p=Ask-Password;if($p){$script:Password=$p;$script:force=$true}})
$quit.add_Click({$script:running=$false})
function Show-Overview(){
 if(-not $script:last){[Windows.Forms.MessageBox]::Show('Noch kein Status geladen.','Anlagenbuch');return}
 [Windows.Forms.MessageBox]::Show("Offene Störungen: $($script:last.openCount)`r`nIn Bearbeitung: $($script:last.progressCount)`r`nTagesgeschäft: $($script:last.todayCount)",'Anlagenbuch Übersicht') | Out-Null
}
$overview.add_Click({Show-Overview})
$seen=@();try{$seen=@(ConvertFrom-Json (Get-Content $SeenFile -Raw))}catch{}
$first=($seen.Count -eq 0);$next=[DateTime]::MinValue
$player=New-Object System.Media.SoundPlayer (Join-Path $Dir 'siren.wav')
while($script:running){
 [Windows.Forms.Application]::DoEvents()
 if($script:force -or (Get-Date) -ge $next){$script:force=$false
  try{
   $headers=@{'X-Anlagenbuch-Password'=$script:Password};$r=Invoke-RestMethod -Uri "$BaseUrl/api/companion/status" -Headers $headers -Method Get -TimeoutSec 25;$script:last=$r
   $ids=@($r.openFaultIds);if($first){$seen=$ids;$first=$false}else{$new=@($ids | Where-Object {$_ -notin $seen});if($new.Count -gt 0){$f=@($r.openFaults | Where-Object {$_.id -in $new})[-1];$title='Neue Störung';if($f.assetName){$title+=' · '+$f.assetName};$notify.BalloonTipTitle=$title;$notify.BalloonTipText=if($f.description){$f.description}else{'Neue Störung im Anlagenbuch'};$notify.BalloonTipIcon='Warning';$notify.ShowBalloonTip(12000);try{$player.Stop();$player.Play()}catch{};$seen=@($seen+$new | Select-Object -Unique)}}
   $seen | ConvertTo-Json | Set-Content -Encoding utf8 $SeenFile;$notify.Text="Anlagenbuch · $($r.openCount) offen · $($r.progressCount) in Arbeit";$next=(Get-Date).AddSeconds(30)
  }catch{
   if($_.Exception.Message -match '401|Passwort'){$notify.BalloonTipTitle='Anlagenbuch Begleiter';$notify.BalloonTipText='Web-Passwort prüfen. Über das Symbol: Passwort ändern.';$notify.ShowBalloonTip(8000);$next=(Get-Date).AddMinutes(2)}else{$next=(Get-Date).AddSeconds(60)}
  }
 }
 Start-Sleep -Milliseconds 250
}
$notify.Visible=$false;$notify.Dispose()
