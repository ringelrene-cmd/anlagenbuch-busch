@echo off
setlocal
set "DEST=%LOCALAPPDATA%\Busch Group\Anlagenbuch-Begleiter"
del /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Anlagenbuch Begleiter.lnk" 2>nul
rmdir /S /Q "%DEST%" 2>nul
echo Anlagenbuch Begleiter wurde entfernt. Falls er noch im Infobereich laeuft, dort einmal Beenden waehlen.
pause
