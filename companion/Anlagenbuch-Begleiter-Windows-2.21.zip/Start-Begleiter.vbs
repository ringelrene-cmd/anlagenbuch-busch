Option Explicit
Dim sh, fso, base, scriptPath, command
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fso.BuildPath(base, "Anlagenbuch-Begleiter.ps1")
If Not fso.FileExists(scriptPath) Then
  MsgBox "Anlagenbuch-Begleiter.ps1 wurde nicht gefunden:" & vbCrLf & scriptPath, vbExclamation, "Anlagenbuch Begleiter"
  WScript.Quit 1
End If
command = "powershell.exe -NoProfile -WindowStyle Hidden -File " & Chr(34) & scriptPath & Chr(34)
sh.Run command, 0, False
